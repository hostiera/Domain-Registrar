<?php
namespace ModulesGarden\DomainsReseller\Registrar\Hostiera\Calls;
use ModulesGarden\DomainsReseller\Registrar\Hostiera\Core\Call;

/**
 * Description of GetNameServers
 *
 * @author inbs
 */
class Sync extends Call
{
    public $action = "domains/:domain/sync";
    
    public $type = parent::TYPE_POST;
}