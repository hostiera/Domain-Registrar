<?php
namespace ModulesGarden\DomainsReseller\Registrar\Hostiera\Calls;
use ModulesGarden\DomainsReseller\Registrar\Hostiera\Core\Call;

/**
 * Description of RequestDelete
 *
 * @author inbs
 */
class RequestDelete extends Call
{
    public $action = "domains/:domain/delete";
    
    public $type = parent::TYPE_POST;
}