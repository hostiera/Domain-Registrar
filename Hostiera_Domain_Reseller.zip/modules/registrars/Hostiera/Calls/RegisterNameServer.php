<?php
namespace ModulesGarden\DomainsReseller\Registrar\Hostiera\Calls;
use ModulesGarden\DomainsReseller\Registrar\Hostiera\Core\Call;

/**
 * Description of RegisterNameServer
 *
 * @author inbs
 */
class RegisterNameServer extends Call
{
    public $action = "domains/:domain/nameservers/register";
    
    public $type = parent::TYPE_POST;
}