<?php
namespace ModulesGarden\DomainsReseller\Registrar\Hostiera\Calls;
use ModulesGarden\DomainsReseller\Registrar\Hostiera\Core\Call;

/**
 * Description of TransferDomain
 *
 * @author inbs
 */
class GetRegistrarLock extends Call
{
    public $action = "domains/:domain/lock";
    
    public $type = parent::TYPE_GET;
}