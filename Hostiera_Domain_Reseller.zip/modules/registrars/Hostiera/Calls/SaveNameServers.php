<?php
namespace ModulesGarden\DomainsReseller\Registrar\Hostiera\Calls;
use ModulesGarden\DomainsReseller\Registrar\Hostiera\Core\Call;

/**
 * Description of SaveNameServers
 *
 * @author inbs
 */
class SaveNameServers extends Call
{
    public $action = "domains/:domain/nameservers";

    public $type = parent::TYPE_POST;
}